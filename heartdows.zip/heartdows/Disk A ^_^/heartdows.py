hmm = print("""


█░█ █▀▀ ▄▀█ █▀█ ▀█▀ █▀▄ █▀█ █░█░█ █▀
█▀█ ██▄ █▀█ █▀▄ ░█░ █▄▀ █▄█ ▀▄▀▄▀ ▄█

""")

lol = input("hi user: ")

lines4 = [lol]
with open('messages/message.html3', 'w')as f: f.writelines(lines4)

name = input("enter name to login: ")

lines = [name]
with open('user/info_name.name_uwu', 'w')as f: f.writelines(lines)

phs = input("enter your password: ")
lines2= [phs]
with open('user/info_pass.pass_uwu', 'w')as f: f.writelines(lines2)
print("")
print("hello " + name)
print("""
[1]shutdown
[2]open text editor 
[3]open website text downloader
""")

ir = input("?: ")

if (ir == '2'):
    inl = input("enter text: ")
    lines8 = [inl]
    with open('notes/text.txt', 'a')as f: f.writelines(lines8)
    
if (ir == '3'):
      web = input("enter or paste your url to save in heartdows/C/downloads/web1.url: _www. ") 
      
      lines12 = [web]
      with open('downloads/web1.url', 'a')as f: f.writelines(lines12)